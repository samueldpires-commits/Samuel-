const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { auth: authLimiter } = require('../middlewares/rateLimiter');

const router = express.Router();
const isProd = process.env.NODE_ENV === 'production';

const cookieOptions = {
  httpOnly: true,
  secure: isProd,          // o original usava secure:true sempre -> login quebrava em http://localhost
  sameSite: 'strict',
  path: '/'
};

// Hash falso para comparar mesmo quando o e-mail não existe (evita descobrir e-mails pelo tempo de resposta)
const DUMMY_HASH = bcrypt.hashSync('senha-falsa-para-tempo-constante', 12);

const emailRule = body('email').isString().trim().isEmail().isLength({ max: 254 }).normalizeEmail();

router.post('/register',
  authLimiter,
  [
    emailRule,
    // bcrypt só considera os primeiros 72 bytes -> limitar evita surpresas e DoS
    body('password').isString().isLength({ min: 12, max: 72 })
      .withMessage('A senha deve ter entre 12 e 72 caracteres')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      const msg = errors.array()[0].msg;
      return res.status(400).json({ error: msg === 'Invalid value' ? 'Dados inválidos' : msg });
    }

    const { email, password } = req.body;
    try {
      const hashed = await bcrypt.hash(password, 12);
      await db.run('INSERT INTO users (email, password) VALUES (?, ?)', [email, hashed]);
      res.status(201).json({ message: 'Usuário criado' });
    } catch (err) {
      if (err.code === 'SQLITE_CONSTRAINT') {
        return res.status(400).json({ error: 'Não foi possível criar a conta com esses dados' });
      }
      console.error('register:', err.message);
      res.status(500).json({ error: 'Erro interno' });
    }
  }
);

router.post('/login',
  authLimiter,
  [emailRule, body('password').isString().isLength({ min: 1, max: 72 })],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'Dados inválidos' });

    const { email, password } = req.body;
    try {
      const row = await db.get('SELECT id, email, password FROM users WHERE email = ?', [email]);
      const match = await bcrypt.compare(password, row ? row.password : DUMMY_HASH);
      if (!row || !match) return res.status(401).json({ error: 'Credenciais inválidas' });

      const token = jwt.sign({ id: row.id, email: row.email }, process.env.JWT_SECRET, {
        algorithm: 'HS256',
        expiresIn: '1h',
        issuer: 'inhackeavel.com'
      });

      res.cookie('jwt', token, { ...cookieOptions, maxAge: 60 * 60 * 1000 });
      res.json({ message: 'Autenticado' });
    } catch (err) {
      console.error('login:', err.message);
      res.status(500).json({ error: 'Erro interno' });
    }
  }
);

router.post('/logout', (req, res) => {
  res.clearCookie('jwt', cookieOptions);
  res.json({ message: 'Deslogado' });
});

module.exports = { authRouter: router };
