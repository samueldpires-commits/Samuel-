const express = require('express');
const auth = require('../middlewares/auth');

const router = express.Router();

router.get('/me', auth, (req, res) => {
  const { id, email } = req.user;
  res.json({ id, email });
});

module.exports = { userRouter: router };
