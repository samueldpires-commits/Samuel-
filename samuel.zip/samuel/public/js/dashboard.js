(async function () {
  const emailEl = document.getElementById('userEmail');

  try {
    const res = await fetch('/api/user/me', { credentials: 'same-origin' });
    if (!res.ok) throw new Error('unauthorized');
    const user = await res.json();
    emailEl.textContent = user.email;   // textContent evita XSS
  } catch (err) {
    window.location.href = '/';
    return;
  }

  document.getElementById('logoutBtn').addEventListener('click', async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'inhackeavel' },
        body: '{}'
      });
    } finally {
      window.location.href = '/';
    }
  });
})();
