(function () {
  const form = document.getElementById('loginForm') || document.getElementById('registerForm');
  if (!form) return;

  const isLogin = form.id === 'loginForm';
  const msg = document.getElementById('message');
  const btn = form.querySelector('button[type="submit"]');

  function show(text, type) {
    msg.textContent = text;          // textContent: nunca innerHTML (evita XSS)
    msg.className = type;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    show('', '');

    const email = form.email.value.trim();
    const password = form.password.value;

    if (!isLogin && password.length < 12) {
      return show('A senha deve ter pelo menos 12 caracteres.', 'error');
    }

    btn.disabled = true;
    try {
      const res = await fetch(isLogin ? '/api/auth/login' : '/api/auth/register', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'inhackeavel'
        },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        return show(data.error || 'Erro ao processar a requisição.', 'error');
      }

      if (isLogin) {
        window.location.href = '/dashboard.html';
      } else {
        show('Conta criada! Redirecionando para o login…', 'ok');
        setTimeout(() => { window.location.href = '/'; }, 1200);
      }
    } catch (err) {
      show('Falha de conexão com o servidor.', 'error');
    } finally {
      btn.disabled = false;
    }
  });
})();
