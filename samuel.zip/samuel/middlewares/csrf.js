// Proteção CSRF sem depender do pacote "csurf" (descontinuado e com vulnerabilidades).
// Camadas: cookie SameSite=Strict + exigir JSON + exigir cabeçalho customizado + checar Origin.
module.exports = (req, res, next) => {
  const safe = ['GET', 'HEAD', 'OPTIONS'];
  if (safe.includes(req.method)) return next();

  const origin = req.get('origin');
  if (origin) {
    const host = req.get('host');
    let originHost;
    try { originHost = new URL(origin).host; } catch { originHost = null; }
    if (originHost !== host) return res.status(403).json({ error: 'Origem não permitida' });
  }

  if (!req.is('application/json') || req.get('x-requested-with') !== 'inhackeavel') {
    return res.status(403).json({ error: 'Requisição inválida' });
  }
  next();
};
