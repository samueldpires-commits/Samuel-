const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.cookies.jwt;
  if (!token) return res.status(401).json({ error: 'Não autorizado' });

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET, {
      algorithms: ['HS256'],        // impede troca de algoritmo
      issuer: 'inhackeavel.com'     // o original assinava com issuer mas não validava
    });
    next();
  } catch (err) {
    res.clearCookie('jwt');
    return res.status(401).json({ error: 'Token inválido' });
  }
};
