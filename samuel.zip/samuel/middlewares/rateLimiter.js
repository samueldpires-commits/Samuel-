const rateLimit = require('express-rate-limit');

const base = { standardHeaders: true, legacyHeaders: false };

module.exports = {
  // Limite geral
  global: rateLimit({
    ...base,
    windowMs: 15 * 60 * 1000,
    limit: 300,
    message: { error: 'Muitas requisições. Tente novamente em alguns minutos.' }
  }),
  // Limite duro para login/registro (barra força bruta)
  auth: rateLimit({
    ...base,
    windowMs: 15 * 60 * 1000,
    limit: 10,
    message: { error: 'Muitas tentativas. Tente novamente depois de 15 minutos.' }
  })
};
